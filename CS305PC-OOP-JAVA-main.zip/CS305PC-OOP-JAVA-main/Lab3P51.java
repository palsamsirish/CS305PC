import java.util.Scanner;
class Lab3P51{
	public void demonstrate(){
		System.out.println("Iam a method in Lab3P51");
	}
	public void setName(String s){
		this.name=s;
	}
	public String getName(){
		return this.name;
		}
		}
		
	
